/* ============================================================
   MODULE 15 — DESTRUCTIBLE BLOCKS + 3×3 BACKGROUND WORLD
   Разрушаемые блоки (сетка 1×1 м = 100×100 px) и связи комнаты с восемью
   соседними фоновыми блоками (N, NE, E, SE, S, SW, W, NW; центр C — эта комната).

   Модуль подключается БЕЗ правок остальных JS-файлов: он оборачивает существующие
   функции (renderRoom, collectRoomJSON, loadRoomFromJSON, scanProjectFolderCatalog,
   populateOpenRoomSelect). Состояние живёт в room.world, поэтому undo/redo из
   MODULE 12 работает для блоков автоматически.

   Тип блока = объект каталога из Object Constructor категории
   «Строительный объект» (переключатель «все объекты» показывает и остальные). Картинки состояний берутся из его блока destruction:
   Целый → appearance.asset · Повреждённый → destruction.damaged.image ·
   Разрушенный → destruction.broken.image · Отсутствует → пустота (проём).
   Нет картинки состояния — рисуется целый вид с трещинами/обломками.

   JSON комнаты (добавляется ключ world, только если он не пустой):
   "world": {
     "blockSizeM": 1,
     "neighbors": { "N":null, "NE":null, "E":"room_b", "SE":null, "S":null, "SW":null, "W":"room_a", "NW":null },
     "blocks": [ { "cx":0, "cy":2, "type":"brick_wall", "state":"INTACT" }, ... ]
   }
   cx, cy — индексы клетки (1 клетка = blockSizeM метров, начало — левый верхний угол комнаты);
   state — начальное состояние: INTACT | DAMAGED | DESTROYED | ABSENT.
   ============================================================ */

/* ---------- константы и состояние ---------- */
const WORLD_UI=!!document.getElementById('worldToolbar'); // без разметки в index.html модуль молча ничего не делает
const BLOCK_SIZE_M=1;
const BLOCK_STATES=['INTACT','DAMAGED','DESTROYED','ABSENT'];
const BLOCK_STATE_LABEL={INTACT:'Целый',DAMAGED:'Повреждённый',DESTROYED:'Разрушенный',ABSENT:'Отсутствует'};
const BLOCK_STATE_GLYPH={INTACT:'',DAMAGED:'½',DESTROYED:'✖',ABSENT:'∅'};
const WORLD_DIRS=['NW','N','NE','W','E','SW','S','SE'];      // порядок на сетке 3×3
const WORLD_JSON_ORDER=['N','NE','E','SE','S','SW','W','NW']; // порядок ключей в JSON — по часовой стрелке
const WORLD_OPPOSITE={N:'S',S:'N',E:'W',W:'E',NE:'SW',SW:'NE',NW:'SE',SE:'NW'};
const WORLD_ARROW={NW:'↖',N:'↑',NE:'↗',W:'←',E:'→',SW:'↙',S:'↓',SE:'↘'};
let blockTool='off';          // off | paint | state | erase
let blockPaintType='';        // id объекта-блока из каталога
let blockPaintState='INTACT';
const blockImgCache=new Map(); // 'тип|СОСТОЯНИЕ' → url | null (нет / ещё грузится)
const neighborCache=new Map(); // id комнаты → {status, name, width, height, layers[]}

function blockPx(){ return PIXELS_PER_METER*BLOCK_SIZE_M; }
function worldState(){
  if(!room.world) room.world={blocks:{},neighbors:{}};
  if(!room.world.blocks) room.world.blocks={};
  if(!room.world.neighbors) room.world.neighbors={};
  return room.world;
}
function blockGridSize(){ const B=blockPx(); return {cols:Math.ceil(room.width/B-1e-9), rows:Math.ceil(room.height/B-1e-9)}; }
function setWorldStatus(text){ const el=document.getElementById('worldStatus'); if(el) el.textContent=text||''; }

/* ---------- типы блоков из каталога ---------- */
function blockCatalogItem(id){ return projectCatalog.find(c=>c.id===id)||null; }
// Палитра блоков: только «Строительный объект» (или все объекты, если включено «все объекты»).
// Флаг destruction.enabled как признак НЕ годится: в ОС он включён по умолчанию у любого объекта.
function blockTypeItems(all){
  return projectCatalog.filter(c=>all||c.category==='building');
}
function blockTypeColor(id){ let h=0; for(const ch of String(id)) h=(h*31+ch.charCodeAt(0))%360; return `hsl(${h} 35% 30%)`; }
// Картинка блока в нужном состоянии. Повреждённый/разрушенный виды подгружаются с диска лениво.
function blockImageUrl(typeId,state){
  if(state==='ABSENT') return null;
  const c=blockCatalogItem(typeId); if(!c) return null;
  if(state==='INTACT') return c.image||null;
  const key=typeId+'|'+state;
  if(blockImgCache.has(key)) return blockImgCache.get(key);
  blockImgCache.set(key,null); // «нет или ещё грузится» — пока рисуем запасной вид
  const d=(c.json&&c.json.destruction)||{};
  const path=(state==='DAMAGED'?d.damaged:d.broken)&&(state==='DAMAGED'?d.damaged:d.broken).image;
  if(path&&projectDirHandle){
    (async()=>{
      try{
        const dir=await getSubdir(projectDirHandle,'assets/sprites',false);
        const u=await spriteUrl(dir,path,null);
        if(u){ blockImgCache.set(key,u); renderRoom(); }
      }catch(e){}
    })();
  }
  return null;
}

/* ---------- отрисовка блоков на холсте ---------- */
function renderBlocks(){
  const stage=document.getElementById('stage'), B=blockPx(), ws=room.world;
  if(blockTool!=='off'){
    const g=document.createElement('div'); g.className='blk-grid dynamic-el';
    g.style.cssText=`width:${room.width}px;height:${room.height}px;background-size:${B}px ${B}px`;
    stage.appendChild(g);
  }
  if(!ws||!ws.blocks) return;
  Object.keys(ws.blocks).forEach(key=>{
    const b=ws.blocks[key], parts=key.split(','), cx=+parts[0], cy=+parts[1];
    const cat=blockCatalogItem(b.type);
    const tile=document.createElement('div');
    let cls='blk dynamic-el blk-'+b.state, fx='';
    let url=blockImageUrl(b.type,b.state);
    if(!url&&(b.state==='DAMAGED'||b.state==='DESTROYED')){ // нет своей картинки состояния — целый вид + эффект
      url=blockImageUrl(b.type,'INTACT'); fx=b.state==='DAMAGED'?' fx-crack':' fx-rubble';
    }
    if(!cat) cls+=' blk-unknown';
    tile.className=cls+fx;
    tile.style.cssText=`left:${cx*B}px;top:${cy*B}px;width:${B}px;height:${B}px`;
    if(url) tile.style.backgroundImage=`url("${url}")`;
    else if(b.state!=='ABSENT') tile.style.backgroundColor=cat?blockTypeColor(b.type):'#3a2a2a';
    tile.title=`${cat?(cat.name||cat.id):b.type+' (нет в каталоге)'} · ${BLOCK_STATE_LABEL[b.state]||b.state} · клетка ${cx},${cy}`;
    const glyph=!cat?'?':BLOCK_STATE_GLYPH[b.state];
    if(glyph){ const gl=document.createElement('span'); gl.className='blk-glyph'; gl.textContent=glyph; tile.appendChild(gl); }
    stage.appendChild(tile);
  });
}

/* ---------- инструменты: рамка по сетке 1 м ---------- */
function setBlockTool(t){
  blockTool=t;
  if(t!=='off'&&typeof setPaintMode==='function') setPaintMode(null); // не мешаем разметке зон
  canvasWrap.classList.toggle('blk-tool-on',t!=='off');
  document.querySelectorAll('[data-blk-tool]').forEach(b=>b.classList.toggle('active',b.dataset.blkTool===t));
  renderRoom();
}
function applyBlockRect(a,b){
  const ws=worldState(), g=blockGridSize();
  const x1=Math.max(0,Math.min(a.cx,b.cx)), x2=Math.min(g.cols-1,Math.max(a.cx,b.cx));
  const y1=Math.max(0,Math.min(a.cy,b.cy)), y2=Math.min(g.rows-1,Math.max(a.cy,b.cy));
  if(x2<x1||y2<y1) return 0;
  if(blockTool==='paint'&&!blockPaintType){ setWorldStatus('Сначала выбери тип блока — объект категории «Строительный объект» из Object Constructor.'); return 0; }
  let n=0;
  for(let cy=y1;cy<=y2;cy++) for(let cx=x1;cx<=x2;cx++){
    const k=cx+','+cy;
    if(blockTool==='paint'){ ws.blocks[k]={type:blockPaintType,state:blockPaintState}; n++; }
    else if(blockTool==='state'){ if(ws.blocks[k]){ ws.blocks[k].state=blockPaintState; n++; } }
    else if(blockTool==='erase'){ if(ws.blocks[k]){ delete ws.blocks[k]; n++; } }
  }
  if(n) scheduleHistoryPush();
  renderRoom();
  return n;
}
function startBlockRect(e){
  const stage=document.getElementById('stage'), B=blockPx();
  const cellAt=ev=>{ const p=clientToRoom(ev); return {cx:Math.floor(p.x/B), cy:Math.floor(p.y/B)}; };
  const a=cellAt(e); let b=a;
  const el=document.createElement('div'); el.className='blk-sel'; stage.appendChild(el);
  const draw=()=>{
    const x1=Math.min(a.cx,b.cx), y1=Math.min(a.cy,b.cy), x2=Math.max(a.cx,b.cx), y2=Math.max(a.cy,b.cy);
    el.style.cssText=`left:${x1*B}px;top:${y1*B}px;width:${(x2-x1+1)*B}px;height:${(y2-y1+1)*B}px`;
  };
  const move=ev=>{ b=cellAt(ev); draw(); };
  const up=()=>{ window.removeEventListener('pointermove',move); el.remove(); applyBlockRect(a,b); };
  window.addEventListener('pointermove',move);
  window.addEventListener('pointerup',up,{once:true});
  draw();
}
function fillBlocks(){
  if(!blockPaintType){ setWorldStatus('Сначала выбери тип блока.'); return; }
  const ws=worldState(), g=blockGridSize();
  if(Object.keys(ws.blocks).length&&!confirm('Заменить все существующие блоки выбранным типом и состоянием?')) return;
  ws.blocks={};
  for(let cy=0;cy<g.rows;cy++) for(let cx=0;cx<g.cols;cx++) ws.blocks[cx+','+cy]={type:blockPaintType,state:blockPaintState};
  scheduleHistoryPush(); renderRoom();
}
function clearBlocks(){
  const ws=worldState();
  if(!Object.keys(ws.blocks).length) return;
  if(!confirm('Удалить все разрушаемые блоки этой комнаты?')) return;
  ws.blocks={}; scheduleHistoryPush(); renderRoom();
}

/* ---------- панель ---------- */
function refreshBlockPalette(){
  const sel=document.getElementById('blockTypeSelect'); if(!sel) return;
  const all=document.getElementById('blockShowAllTypes').checked;
  const items=blockTypeItems(all), prev=blockPaintType;
  if(!projectDirHandle) sel.innerHTML='<option value="">— подключи папку проекта —</option>';
  else if(!items.length) sel.innerHTML='<option value="">— нет объектов категории «Строительный объект» —</option>';
  else sel.innerHTML=items.map(c=>`<option value="${esc(c.id)}">${esc(c.name||c.id)}${c.category==='building'?'':' (не строительный)'}</option>`).join('');
  sel.value=items.some(c=>c.id===prev)?prev:(items[0]?items[0].id:'');
  blockPaintType=sel.value;
}
function updateWorldPanel(){
  if(!WORLD_UI) return;
  const ws=room.world||{blocks:{},neighbors:{}}, g=blockGridSize();
  const counts={INTACT:0,DAMAGED:0,DESTROYED:0,ABSENT:0}; let total=0, unknown=0, outside=0;
  Object.keys(ws.blocks||{}).forEach(k=>{
    const b=ws.blocks[k], p=k.split(','), cx=+p[0], cy=+p[1];
    total++; counts[b.state]=(counts[b.state]||0)+1;
    if(!blockCatalogItem(b.type)) unknown++;
    if(cx<0||cy<0||cx>=g.cols||cy>=g.rows) outside++;
  });
  const B=blockPx(), notWhole=(room.width%B!==0)||(room.height%B!==0);
  let txt=total
    ? `Блоков: ${total} (целых ${counts.INTACT}, повреждённых ${counts.DAMAGED}, разрушенных ${counts.DESTROYED}, отсутствуют ${counts.ABSENT})`
    : 'Блоков пока нет.';
  txt+=` · сетка ${g.cols}×${g.rows} по ${BLOCK_SIZE_M} м`;
  if(notWhole) txt+=' · размер комнаты не кратен 1 м — крайние блоки выступают за границу';
  if(unknown) txt+=` · ⚠ типов нет в каталоге: ${unknown}`;
  if(outside) txt+=` · ⚠ вне комнаты: ${outside} (сохранятся; сотри их или увеличь комнату)`;
  const sum=document.getElementById('blockSummary'); if(sum) sum.textContent=txt;
  const shortEl=document.getElementById('blockSummaryShort'); if(shortEl) shortEl.textContent=total?`· блоков: ${total}`:'';
  WORLD_DIRS.forEach(d=>{
    const sel=document.getElementById('worldNb_'+d); if(!sel) return;
    const v=(ws.neighbors&&ws.neighbors[d])||'';
    if(v&&![...sel.options].some(o=>o.value===v)) sel.insertAdjacentHTML('beforeend',`<option value="${esc(v)}">${esc(v)} (нет файла)</option>`);
    sel.value=v;
  });
}
function buildWorldGrid(){
  const box=document.getElementById('worldGrid'); if(!box) return;
  const order=['NW','N','NE','W','C','E','SW','S','SE'];
  box.innerHTML=order.map(d=>d==='C'
    ? '<div class="world-center" title="Эта комната — центральный блок">C · эта комната</div>'
    : `<select id="worldNb_${d}" data-dir="${d}" title="Соседний фоновый блок: ${d}"></select>`).join('');
  WORLD_DIRS.forEach(d=>{
    const sel=document.getElementById('worldNb_'+d);
    sel.onchange=()=>{ worldState().neighbors[d]=sel.value||null; scheduleHistoryPush(); renderRoom(); };
  });
  populateWorldSelects();
}
function populateWorldSelects(){
  const me=sanitizeSlug(room.id||(document.getElementById('roomId')||{}).value||'');
  WORLD_DIRS.forEach(d=>{
    const sel=document.getElementById('worldNb_'+d); if(!sel) return;
    const cur=sel.value;
    sel.innerHTML=`<option value="">${WORLD_ARROW[d]} ${d} — нет</option>`+
      existingRoomsList.filter(r=>r.id!==me).map(r=>`<option value="${esc(r.id)}">${WORLD_ARROW[d]} ${d}: ${esc(r.name||r.id)}</option>`).join('');
    sel.value=cur;
  });
}

/* ---------- соседи: предпросмотр на холсте ---------- */
function ensureNeighbor(id){
  if(neighborCache.has(id)) return neighborCache.get(id);
  const rec={status:'loading',layers:[]};
  neighborCache.set(id,rec);
  (async()=>{
    try{
      if(!projectDirHandle) throw new Error('нет папки проекта');
      const dir=await getSubdir(projectDirHandle,'data/rooms',false);
      const data=roomFromJSON(JSON.parse(await (await (await dir.getFileHandle(id+'.json')).getFile()).text()));
      const sprites=await getSubdir(projectDirHandle,'assets/sprites',false);
      const layers=[];
      for(const l of (data.backgroundLayers||[])){
        try{
          const url=await loadImageDataUrl(sprites,l.image), d=await getImageDims(url), sc=bgScaleFromJSON(l,d.w);
          layers.push({url,w:d.w*sc,h:d.h*sc,x:l.x,y:l.y,opacity:l.opacity!==undefined?l.opacity:1,rotation:l.rotation||0,flipH:!!l.flipH,flipV:!!l.flipV});
        }catch(e){}
      }
      Object.assign(rec,{status:'ok',name:data.name||id,width:data.width,height:data.height,layers});
    }catch(e){ rec.status='error'; }
    renderRoom();
  })();
  return rec;
}
// Прямоугольник соседа в координатах холста комнаты: соседи примыкают к углам центральной комнаты
function neighborRect(d){
  const id=(room.world&&room.world.neighbors&&room.world.neighbors[d])||null;
  const rec=id&&neighborCache.get(id), w=(rec&&rec.width)||room.width, h=(rec&&rec.height)||room.height;
  const x=d.includes('W')?-w:(d.includes('E')?room.width:0), y=d.includes('N')?-h:(d.includes('S')?room.height:0);
  return {x,y,w,h,id};
}
function renderNeighborPreview(){
  const chk=document.getElementById('worldShowNeighbors');
  if(!chk||!chk.checked||!room.world||!room.world.neighbors) return;
  const stage=document.getElementById('stage');
  WORLD_DIRS.forEach(d=>{
    const id=room.world.neighbors[d]; if(!id) return;
    const r=neighborRect(d), rec=ensureNeighbor(id);
    if(rec.status==='ok') rec.layers.forEach(l=>{
      const img=document.createElement('img'); img.className='nb-layer dynamic-el'; img.src=l.url;
      img.style.cssText=`left:${r.x+l.x-l.w/2}px;top:${r.y+l.y-l.h/2}px;width:${l.w}px;height:${l.h}px;opacity:${l.opacity*0.6};`+
        `transform:rotate(${l.rotation}deg) scaleX(${l.flipH?-1:1}) scaleY(${l.flipV?-1:1})`;
      stage.appendChild(img);
    });
    const fr=document.createElement('div'); fr.className='nb-frame dynamic-el';
    fr.style.cssText=`left:${r.x}px;top:${r.y}px;width:${r.w}px;height:${r.h}px`;
    const lb=document.createElement('span'); lb.className='nb-label';
    lb.textContent=`${WORLD_ARROW[d]} ${d}: ${rec.name||id}${rec.status==='error'?' (нет данных)':(rec.status==='loading'?' …':'')}`;
    fr.appendChild(lb); stage.appendChild(fr);
  });
}
// Вписать в экран комнату (и соседей, если они показаны)
function fitWorldView(){
  const W=canvasWrap.clientWidth||900, H=canvasWrap.clientHeight||500;
  let minX=0,minY=0,maxX=room.width,maxY=room.height;
  const chk=document.getElementById('worldShowNeighbors');
  if(chk&&chk.checked&&room.world&&room.world.neighbors) WORLD_DIRS.forEach(d=>{
    if(!room.world.neighbors[d]) return;
    const r=neighborRect(d); minX=Math.min(minX,r.x); minY=Math.min(minY,r.y); maxX=Math.max(maxX,r.x+r.w); maxY=Math.max(maxY,r.y+r.h);
  });
  const z=Math.max(0.1,Math.min(6,Math.min((W-40)/(maxX-minX),(H-40)/(maxY-minY))));
  zoom=z; panX=-((minX+maxX)/2)*z; panY=-((minY+maxY)/2)*z;
  applyStageTransform();
}

/* ---------- согласованность связей N↔S, E↔W, NE↔SW, NW↔SE ---------- */
async function loadAllWorldLinks(){
  const out={};
  if(!projectDirHandle) return out;
  try{
    const dir=await getSubdir(projectDirHandle,'data/rooms',false);
    for await(const [name,h] of dir.entries()){
      if(h.kind!=='file'||!name.endsWith('.json')) continue;
      try{ const d=JSON.parse(await (await h.getFile()).text()); out[name.replace(/\.json$/,'')]={neighbors:(d.world&&d.world.neighbors)||{}}; }catch(e){}
    }
  }catch(e){}
  return out;
}
async function analyzeWorldLinks(){
  if(!projectDirHandle) return {error:'Сначала подключи папку проекта.'};
  const me=sanitizeSlug(room.id||document.getElementById('roomId').value||'');
  if(!me) return {error:'Сначала задай id комнаты.'};
  const links=await loadAllWorldLinks();
  const unsaved=!(me in links);
  const cur={}; WORLD_DIRS.forEach(d=>{ const v=room.world&&room.world.neighbors&&room.world.neighbors[d]; if(v) cur[d]=v; });
  links[me]={neighbors:cur}; // текущее состояние редактора важнее файла на диске
  const get=(r,d)=>((links[r]&&links[r].neighbors)||{})[d]||null;
  const issues=[];
  Object.keys(links).forEach(r=>WORLD_DIRS.forEach(d=>{
    const t=get(r,d); if(!t) return;
    if(r!==me&&t!==me) return; // интересуют только связи, касающиеся этой комнаты
    if(t===r){ issues.push({r,d,t,kind:'self'}); return; }
    if(!links[t]){ issues.push({r,d,t,kind:'missing'}); return; }
    const back=get(t,WORLD_OPPOSITE[d]);
    if(back!==r) issues.push({r,d,t,back,kind:back?'conflict':'empty'});
  }));
  return {me,links,issues,unsaved};
}
function describeWorldIssue(i){
  const o=WORLD_OPPOSITE[i.d];
  if(i.kind==='self') return `«${i.r}» ${i.d} ссылается сама на себя`;
  if(i.kind==='missing') return `«${i.r}» ${i.d} → «${i.t}»: комнаты «${i.t}» нет в папке проекта`;
  if(i.kind==='conflict') return `«${i.r}» ${i.d} → «${i.t}», но у «${i.t}» на ${o} стоит «${i.back}»`;
  return `«${i.r}» ${i.d} → «${i.t}», но у «${i.t}» на ${o} пусто`;
}
async function checkWorldLinks(){
  const a=await analyzeWorldLinks();
  if(a.error){ setWorldStatus(a.error); return; }
  if(!a.issues.length){ setWorldStatus('✓ Связи согласованы (N↔S, E↔W, NE↔SW, NW↔SE).'+(a.unsaved?' Комната ещё не сохранена в папку.':'')); return; }
  setWorldStatus('⚠ '+a.issues.slice(0,8).map(describeWorldIssue).join(' · ')+(a.issues.length>8?` · …ещё ${a.issues.length-8}`:''));
}
// Проставляет только недостающие обратные связи (пустые слоты); конфликты не трогает
async function fixWorldLinks(){
  const a=await analyzeWorldLinks();
  if(a.error){ setWorldStatus(a.error); return; }
  const fixes=a.issues.filter(i=>i.kind==='empty');
  if(!fixes.length){ setWorldStatus(a.issues.length?'Осталось только то, что нужно решить вручную (конфликты и отсутствующие комнаты).':'✓ Проставлять нечего.'); return; }
  const filesToWrite=[...new Set(fixes.filter(f=>f.r===a.me).map(f=>f.t))];
  if(filesToWrite.length&&a.unsaved){ setWorldStatus('Сначала сохрани эту комнату — иначе соседи будут ссылаться на несуществующий файл.'); return; }
  if(!confirm(`Проставить обратные связи: ${fixes.length}.\n`+(filesToWrite.length?`Будут изменены файлы комнат: ${filesToWrite.join(', ')}.\n`:'')+'Продолжить?')) return;
  let local=false;
  try{
    for(const f of fixes){
      const opp=WORLD_OPPOSITE[f.d];
      if(f.r===a.me){
        const dir=await getSubdir(projectDirHandle,'data/rooms',false);
        const data=JSON.parse(await (await (await dir.getFileHandle(f.t+'.json')).getFile()).text());
        data.world=data.world||{}; data.world.blockSizeM=data.world.blockSizeM||BLOCK_SIZE_M;
        data.world.neighbors=data.world.neighbors||{}; WORLD_DIRS.forEach(k=>{ if(!(k in data.world.neighbors)) data.world.neighbors[k]=null; });
        if(!data.world.blocks) data.world.blocks=[];
        data.world.neighbors[opp]=a.me;
        await writeFileToProject('data/rooms/'+f.t+'.json', new TextEncoder().encode(JSON.stringify(data,null,2)));
      } else if(f.t===a.me){ worldState().neighbors[opp]=f.r; local=true; }
    }
    if(local){ scheduleHistoryPush(); renderRoom(); }
    neighborCache.clear();
    setWorldStatus(`✓ Проставлено связей: ${fixes.length}.`+(local?' Не забудь сохранить эту комнату.':''));
  }catch(e){ console.error(e); setWorldStatus('Не удалось проставить связи: '+e.message); }
}

/* ---------- JSON ---------- */
function worldToJSON(){
  const ws=room.world; if(!ws) return null;
  const blocks=Object.keys(ws.blocks||{}).map(k=>{ const p=k.split(','), b=ws.blocks[k]; return {cx:+p[0],cy:+p[1],type:b.type,state:b.state}; })
    .sort((a,b)=>a.cy-b.cy||a.cx-b.cx);
  const neighbors={}; let any=false;
  WORLD_JSON_ORDER.forEach(d=>{ const v=(ws.neighbors&&ws.neighbors[d])||null; neighbors[d]=v; if(v) any=true; });
  if(!blocks.length&&!any) return null; // комната без мира — JSON остаётся прежним
  return {blockSizeM:BLOCK_SIZE_M,neighbors,blocks};
}
function worldFromJSON(w){
  const out={blocks:{},neighbors:{}};
  if(w){
    (w.blocks||[]).forEach(b=>{ if(Number.isInteger(b.cx)&&Number.isInteger(b.cy)) out.blocks[b.cx+','+b.cy]={type:b.type,state:BLOCK_STATES.includes(b.state)?b.state:'INTACT'}; });
    WORLD_DIRS.forEach(d=>{ out.neighbors[d]=(w.neighbors&&w.neighbors[d])||null; });
  }
  return out;
}

/* ---------- подключение к существующему коду (обёртки) ---------- */
const __collectRoomJSON=collectRoomJSON;
collectRoomJSON=function(){ const j=__collectRoomJSON(); const w=worldToJSON(); if(w) j.world=w; return j; };

const __loadRoomFromJSON=loadRoomFromJSON;
loadRoomFromJSON=async function(data){
  await __loadRoomFromJSON(data);
  room.world=worldFromJSON(data&&data.world);
  neighborCache.clear();
  renderRoom();
};

const __renderRoom=renderRoom;
renderRoom=function(){
  __renderRoom();
  if(!WORLD_UI) return;
  try{ renderNeighborPreview(); renderBlocks(); updateWorldPanel(); }catch(e){ console.warn('MODULE 15 (мир):',e); }
};

const __scanProjectFolderCatalog=scanProjectFolderCatalog;
scanProjectFolderCatalog=async function(){
  blockImgCache.forEach(u=>{ if(u) URL.revokeObjectURL(u); });
  blockImgCache.clear(); neighborCache.clear();
  await __scanProjectFolderCatalog();
  refreshBlockPalette(); renderRoom();
};

const __populateOpenRoomSelect=populateOpenRoomSelect;
populateOpenRoomSelect=function(){ __populateOpenRoomSelect(); if(WORLD_UI){ populateWorldSelects(); updateWorldPanel(); } };

/* ---------- события интерфейса ---------- */
if(WORLD_UI){
  // рамка по сетке: перехватываем нажатие раньше обычного выделения/перетаскивания
  canvasWrap.addEventListener('pointerdown',e=>{
    if(blockTool==='off'||e.button!==0) return;
    e.preventDefault(); e.stopPropagation();
    startBlockRect(e);
  },true);
  document.querySelectorAll('[data-blk-tool]').forEach(b=>b.onclick=()=>setBlockTool(b.dataset.blkTool));
  ['paintNone','paintRed','paintGreen','paintOrange','paintEraser'].forEach(id=>{
    const el=document.getElementById(id); if(el) el.addEventListener('click',()=>{ if(blockTool!=='off') setBlockTool('off'); }); // разметка зон и блоки не работают одновременно
  });
  document.getElementById('blockTypeSelect').onchange=()=>{ blockPaintType=document.getElementById('blockTypeSelect').value; };
  document.getElementById('blockStateSelect').onchange=()=>{ blockPaintState=document.getElementById('blockStateSelect').value; };
  document.getElementById('blockShowAllTypes').onchange=refreshBlockPalette;
  document.getElementById('btnBlocksFill').onclick=fillBlocks;
  document.getElementById('btnBlocksClear').onclick=clearBlocks;
  document.getElementById('worldShowNeighbors').onchange=()=>{ fitWorldView(); renderRoom(); };
  document.getElementById('btnWorldFit').onclick=fitWorldView;
  document.getElementById('btnWorldCheck').onclick=checkWorldLinks;
  document.getElementById('btnWorldFixLinks').onclick=fixWorldLinks;
  // копия комнаты не наследует соседей оригинала (иначе связи стали бы несимметричными)
  document.getElementById('btnDuplicateRoom').addEventListener('click',()=>{ if(room.world) room.world.neighbors={}; renderRoom(); });
  document.getElementById('blockStateSelect').innerHTML=BLOCK_STATES.map(s=>`<option value="${s}">${BLOCK_STATE_LABEL[s]}</option>`).join('');
  buildWorldGrid();
  refreshBlockPalette();
  updateWorldPanel();
}
